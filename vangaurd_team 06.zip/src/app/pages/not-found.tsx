import React from "react";

export const NotFoundPage: React.FunctionComponent = React.memo(() => {
	return <p>Page not found. Sorry! Go back to the root?</p>;
});
